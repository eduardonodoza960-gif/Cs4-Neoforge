package com.cs.reliquia.mixin.client;

import com.cs.reliquia.CsReliquia;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.entity.state.PlayerRenderState;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Com o Lampião Lendário na mão: no inventário (boneco) e na SUA terceira pessoa a armadura e os itens
 * das mãos não são desenhados. Os ícones dos slots e a primeira pessoa continuam normais.
 */
@Mixin(PlayerRenderer.class)
public abstract class PlayerRendererMixin {

    @Unique
    private int[] cs$slots = null;
    @Unique
    private ItemStack[] cs$guardados = null;

    @Inject(method = "extractRenderState(Lnet/minecraft/client/player/AbstractClientPlayer;Lnet/minecraft/client/renderer/entity/state/PlayerRenderState;F)V",
            at = @At("HEAD"))
    private void cs$esconder(AbstractClientPlayer player, PlayerRenderState state, float delta, CallbackInfo ci) {
        cs$slots = null;
        cs$guardados = null;

        Minecraft mc = Minecraft.getInstance();
        if (player != mc.player) return;
        if (mc.screen == null && mc.options.getCameraType().isFirstPerson()) return;

        boolean lampiao = CsReliquia.temId(player.getMainHandItem(), CsReliquia.LAMPIAO_ID)
                       || CsReliquia.temId(player.getOffhandItem(), CsReliquia.LAMPIAO_ID);
        if (!lampiao) return;

        Inventory inv = player.getInventory();
        // 36 botas, 37 calças, 38 peitoral, 39 capacete, 40 mão secundária, e o slot da mão principal
        int[] slots = {36, 37, 38, 39, 40, inv.selected};
        ItemStack[] guardados = new ItemStack[slots.length];
        for (int i = 0; i < slots.length; i++) {
            ItemStack atual = inv.getItem(slots[i]);
            guardados[i] = atual;
            boolean manter = (slots[i] == 38 && atual.is(Items.ELYTRA))
                          || (slots[i] == 39 && atual.is(Items.CARVED_PUMPKIN));
            if (!manter) inv.setItem(slots[i], ItemStack.EMPTY);
        }
        cs$slots = slots;
        cs$guardados = guardados;
    }

    @Inject(method = "extractRenderState(Lnet/minecraft/client/player/AbstractClientPlayer;Lnet/minecraft/client/renderer/entity/state/PlayerRenderState;F)V",
            at = @At("TAIL"))
    private void cs$restaurar(AbstractClientPlayer player, PlayerRenderState state, float delta, CallbackInfo ci) {
        if (cs$slots == null) return;
        Inventory inv = player.getInventory();
        for (int i = 0; i < cs$slots.length; i++) {
            inv.setItem(cs$slots[i], cs$guardados[i]);
        }
        cs$slots = null;
        cs$guardados = null;
    }
}
