package com.cs.reliquia;

import com.cs.reliquia.mixin.PlayerAccessor;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import com.mojang.datafixers.util.Pair;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.core.GlobalPos;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.network.protocol.game.ClientboundPlayerInfoRemovePacket;
import net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket;
import net.minecraft.network.protocol.game.ClientboundRemoveEntitiesPacket;
import net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket;
import net.minecraft.network.protocol.game.ClientboundSetEquipmentPacket;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerEntity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Unit;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.AreaEffectCloud;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.DragonFireball;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ThrownPotion;
import net.minecraft.world.entity.projectile.ThrownTrident;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.minecraft.world.item.component.LodestoneTracker;
import net.minecraft.world.item.component.ResolvableProfile;
import net.minecraft.world.item.component.Unbreakable;
import net.minecraft.world.item.component.UseCooldown;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.util.TriState;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.entity.ProjectileImpactEvent;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.living.LivingShieldBlockEvent;
import net.neoforged.neoforge.event.entity.player.AttackEntityEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.level.BlockEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.BiConsumer;

@Mod("csreliquia")
@EventBusSubscriber(modid = "csreliquia")
public class CsReliquia {

    private static final Logger LOG = LoggerFactory.getLogger("csreliquia");

    public static final String TAG = "CsItem";
    public static final String ESPADA_ID = "espada_cacador";
    public static final String PENA_ID = "pena_lendaria";
    public static final String ESCUDO_ID = "escudo_lendario";
    public static final String POCAO_ID = "pocao_lendaria";
    public static final String TRIDENTE_ID = "tridente_lendario";
    public static final String PICARETA_ID = "picareta_lendaria";
    public static final String CAPACETE_ID = "capacete_gemeos";
    public static final String DRAGAO_ID = "dragao_area";
    public static final String RELOGIO_ID = "relogio_lendario";
    public static final String LAMPIAO_ID = "lampiao_lendario";
    public static final String BUSSOLA_ID = "bussola_lendaria";
    public static final String BATATA_ID = "batata_do_bobo";
    public static final String BOTA_ID = "bota_lendaria";

    // ---- Rajada do Warden (Escudo) ----
    private static final double ALCANCE = 15.0;
    private static final float DANO = 5.5f;
    private static final double KB_HORIZONTAL = 1.2;
    private static final double KB_VERTICAL = 0.5;
    private static final double DESCIDA = 0.18;
    private static final int COOLDOWN_ESCUDO = 200;   // 10 s
    private static final int COOLDOWN_POCAO = 100;    // 5 s
    private static final int COOLDOWN_DRAGAO = 200;   // 10 s

    private static final Map<UUID, Integer> RAIO_MARCADO = new HashMap<>();
    private static final Set<UUID> GEMEOS = new HashSet<>();
    public static final Set<Integer> OCULTOS = ConcurrentHashMap.newKeySet();

    private static final Map<UUID, GameProfile> ORIGINAIS = new HashMap<>();
    private static final Map<UUID, Disfarce> DISFARCES = new HashMap<>();

    private static class Disfarce {
        UUID alvo;
        List<Property> textura;
        Disfarce(UUID alvo, List<Property> textura) { this.alvo = alvo; this.textura = textura; }
    }

    private static class Lancada {
        ThrownPotion entidade; Vec3 pos; UUID dono; ServerLevel mundo;
    }
    private static final List<Lancada> LANCADAS = new ArrayList<>();
    private static final List<AreaEffectCloud> NUVENS = new ArrayList<>();

    private static final Map<String, Long> USOS = new HashMap<>();
    private static final Map<String, Long> USOS_CLIENTE = new HashMap<>();

    private static HolderLookup.Provider lookup;

    public CsReliquia() {
        LOG.info("CS Rel\u00edquia carregado (NeoForge 1.21.4)");
    }

    // =====================================================================
    // Identificação dos itens
    // =====================================================================
    public static String idDe(ItemStack stack) {
        if (stack.isEmpty()) return "";
        CustomData c = stack.get(DataComponents.CUSTOM_DATA);
        return c == null ? "" : c.copyTag().getString(TAG);
    }

    public static boolean temId(ItemStack stack, String id) {
        return id.equals(idDe(stack));
    }

    public static boolean isReliquia(ItemStack stack) {
        return !idDe(stack).isEmpty();
    }

    private static ServerLevel mundo(Entity e) {
        return (ServerLevel) e.level();
    }

    // =====================================================================
    // Comando /cs4
    // =====================================================================
    @SubscribeEvent
    public static void comandos(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("cs4").executes(ctx -> {
            ServerPlayer jogador = ctx.getSource().getPlayerOrException();
            try {
                abrirMenu(jogador);
                LOG.info("/cs4 usado por {}", jogador.getGameProfile().getName());
            } catch (Exception e) {
                LOG.error("Erro ao abrir o menu /cs4", e);
                jogador.sendSystemMessage(Component.literal("\u00a7cErro ao abrir o menu. Veja o log do servidor."));
            }
            return 1;
        }));
    }

    // =====================================================================
    // Efeitos "de repetição" a cada tick
    // =====================================================================
    private static void aplicar(ServerPlayer player, Holder<MobEffect> efeito, int amplificador, int duracao) {
        MobEffectInstance atual = player.getEffect(efeito);
        if (atual == null || atual.getDuration() < duracao || atual.getAmplifier() != amplificador) {
            player.addEffect(new MobEffectInstance(efeito, duracao, amplificador, false, false, true));
        }
    }

    private static boolean temNoInventario(ServerPlayer p, String id) {
        for (int i = 0; i < p.getInventory().getContainerSize(); i++) {
            if (temId(p.getInventory().getItem(i), id)) return true;
        }
        return false;
    }

    @SubscribeEvent
    public static void tick(ServerTickEvent.Post event) {
        MinecraftServer server = event.getServer();
        int tick = server.getTickCount();
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            ItemStack main = player.getMainHandItem();
            ItemStack off = player.getOffhandItem();

            if (temId(main, ESPADA_ID) || temId(off, ESPADA_ID)) {
                aplicar(player, MobEffects.BAD_OMEN, 5, 20);
            }
            if (temId(main, PENA_ID) || temId(off, PENA_ID)) {
                aplicar(player, MobEffects.LEVITATION, 12, 80);
            }

            if (temId(player.getItemBySlot(EquipmentSlot.HEAD), CAPACETE_ID)) {
                GEMEOS.add(player.getUUID());
                aplicar(player, MobEffects.WATER_BREATHING, 0, 200);
            } else {
                GEMEOS.remove(player.getUUID());
            }

            if (temId(player.getItemBySlot(EquipmentSlot.FEET), BOTA_ID)) {
                aplicar(player, MobEffects.MOVEMENT_SPEED, 4, 80);
            }

            boolean lampiao = temId(main, LAMPIAO_ID) || temId(off, LAMPIAO_ID);
            if (lampiao) {
                aplicar(player, MobEffects.INVISIBILITY, 12, 20);
            }
            atualizarOcultacao(player, lampiao);

            if (temNoInventario(player, BATATA_ID)) {
                aplicar(player, MobEffects.MOVEMENT_SLOWDOWN, 4, 20);
            }

            if (tick % 10 == 0) {
                for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
                    ItemStack s = player.getInventory().getItem(i);
                    if (temId(s, BUSSOLA_ID)) atualizarBussola(s, server);
                }
            }
        }
        if (tick % 20 == 0) acompanharSkins(server);
        processarPocoes();
    }

    // =====================================================================
    // Botão direito
    // =====================================================================
    private static InteractionResult clienteUsar(String id, int ticks) {
        long agora = System.currentTimeMillis();
        Long ultimo = USOS_CLIENTE.get(id);
        if (ultimo != null && agora - ultimo < ticks * 50L - 300L) return InteractionResult.FAIL;
        USOS_CLIENTE.put(id, agora);
        return InteractionResult.SUCCESS;
    }

    private static boolean emRecarga(ServerPlayer p, String id, int ticks) {
        Long ultimo = USOS.get(p.getUUID() + ":" + id);
        if (ultimo == null) return false;
        return System.currentTimeMillis() - ultimo < ticks * 50L - 600L;
    }

    private static void marcarUso(ServerPlayer p, String id) {
        USOS.put(p.getUUID() + ":" + id, System.currentTimeMillis());
    }

    private static void resultado(PlayerInteractEvent.RightClickItem e, InteractionResult r) {
        e.setCanceled(true);
        e.setCancellationResult(r);
    }

    @SubscribeEvent
    public static void usarItem(PlayerInteractEvent.RightClickItem e) {
        ItemStack stack = e.getItemStack();
        String id = idDe(stack);
        if (id.isEmpty()) return;
        InteractionHand hand = e.getHand();

        if (e.getLevel().isClientSide()) {
            InteractionResult r = null;
            if (id.equals(ESCUDO_ID)) r = clienteUsar(id, COOLDOWN_ESCUDO);
            else if (id.equals(POCAO_ID)) r = clienteUsar(id, COOLDOWN_POCAO);
            else if (id.equals(DRAGAO_ID)) r = clienteUsar(id, COOLDOWN_DRAGAO);
            else if (id.equals(RELOGIO_ID) || id.equals(BUSSOLA_ID)) r = InteractionResult.SUCCESS;
            if (r != null) resultado(e, r);
            return;
        }

        if (!(e.getEntity() instanceof ServerPlayer sp)) return;

        if (id.equals(ESCUDO_ID)) {
            if (emRecarga(sp, ESCUDO_ID, COOLDOWN_ESCUDO)) { resultado(e, InteractionResult.FAIL); return; }
            soltarRajada(sp);
            sp.getCooldowns().addCooldown(stack, COOLDOWN_ESCUDO);
            marcarUso(sp, ESCUDO_ID);
            sp.swing(hand, true);
            resultado(e, InteractionResult.SUCCESS);
        } else if (id.equals(POCAO_ID)) {
            if (emRecarga(sp, POCAO_ID, COOLDOWN_POCAO)) { resultado(e, InteractionResult.FAIL); return; }
            lancarPocao(sp, stack);
            sp.swing(hand, true);
            sp.containerMenu.broadcastFullState(); // a poção volta (não gasta)
            resultado(e, InteractionResult.SUCCESS);
        } else if (id.equals(DRAGAO_ID)) {
            resultado(e, dispararBafo(sp, stack) ? InteractionResult.SUCCESS : InteractionResult.FAIL);
        } else if (id.equals(RELOGIO_ID)) {
            abrirSelecao(sp, false, CsReliquia::trocarSkin);
            sp.swing(hand, true);
            resultado(e, InteractionResult.SUCCESS);
        } else if (id.equals(BUSSOLA_ID)) {
            abrirSelecao(sp, true, (eu, alvo) -> escolherAlvo(eu, alvo, hand));
            sp.swing(hand, true);
            resultado(e, InteractionResult.SUCCESS);
        }
    }

    // Dragão e Lampião não são colocados no chão; clicar num bloco com o Dragão também solta a bola
    @SubscribeEvent
    public static void usarBloco(PlayerInteractEvent.RightClickBlock e) {
        ItemStack stack = e.getItemStack();
        String id = idDe(stack);
        if (!id.equals(DRAGAO_ID) && !id.equals(LAMPIAO_ID)) return;
        e.setUseItem(TriState.FALSE);
        if (id.equals(DRAGAO_ID) && !e.getLevel().isClientSide() && e.getEntity() instanceof ServerPlayer sp) {
            dispararBafo(sp, stack);
        }
    }

    @SubscribeEvent
    public static void colocar(BlockEvent.EntityPlaceEvent e) {
        if (e.getEntity() instanceof Player p
                && (isReliquia(p.getMainHandItem()) || isReliquia(p.getOffhandItem()))) {
            e.setCanceled(true);
        }
    }

    // =====================================================================
    // Poção Lendária
    // =====================================================================
    private static void lancarPocao(ServerPlayer player, ItemStack stack) {
        ServerLevel level = mundo(player);

        ItemStack lingering = new ItemStack(Items.LINGERING_POTION);
        lingering.set(DataComponents.POTION_CONTENTS, stack.get(DataComponents.POTION_CONTENTS));

        ThrownPotion entidade = Projectile.spawnProjectileFromRotation(
            ThrownPotion::new, level, lingering, player, -20.0F, 0.5F, 1.0F);

        Lancada l = new Lancada();
        l.entidade = entidade; l.pos = entidade.position(); l.dono = player.getUUID(); l.mundo = level;
        LANCADAS.add(l);

        level.playSound(null, player.getX(), player.getY(), player.getZ(),
            SoundEvents.LINGERING_POTION_THROW, SoundSource.PLAYERS, 0.5F,
            0.4F / (level.getRandom().nextFloat() * 0.4F + 0.8F));

        player.getCooldowns().addCooldown(stack, COOLDOWN_POCAO);
        marcarUso(player, POCAO_ID);
    }

    /** Acha a nuvem criada pela poção e mantém a cegueira travada em 10 s em quem está dentro. */
    private static void processarPocoes() {
        Iterator<Lancada> it = LANCADAS.iterator();
        while (it.hasNext()) {
            Lancada l = it.next();
            if (l.entidade.isRemoved()) {
                AABB caixa = new AABB(l.pos, l.pos).inflate(4.0);
                for (AreaEffectCloud c : l.mundo.getEntitiesOfClass(AreaEffectCloud.class, caixa, x -> x.tickCount <= 5)) {
                    LivingEntity dono = c.getOwner();
                    if (dono != null && dono.getUUID().equals(l.dono) && !NUVENS.contains(c)) {
                        NUVENS.add(c);
                    }
                }
                it.remove();
            } else {
                l.pos = l.entidade.position();
            }
        }

        NUVENS.removeIf(c -> c.isRemoved());
        for (AreaEffectCloud c : NUVENS) {
            float r = c.getRadius();
            if (r < 0.5f) continue;
            ServerLevel w = (ServerLevel) c.level();
            AABB caixa = new AABB(c.getX() - r, c.getY() - 1.0, c.getZ() - r, c.getX() + r, c.getY() + 2.0, c.getZ() + r);
            for (LivingEntity e : w.getEntitiesOfClass(LivingEntity.class, caixa, x -> x.isAlive())) {
                double dx = e.getX() - c.getX(), dz = e.getZ() - c.getZ();
                if (dx * dx + dz * dz > r * r) continue;
                MobEffectInstance atual = e.getEffect(MobEffects.BLINDNESS);
                if (atual == null || atual.getDuration() < 200) {
                    e.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 200, 0, false, true, true));
                }
            }
        }
    }

    // =====================================================================
    // Dragão Lendário: bola de fogo do Dragão do Fim
    // =====================================================================
    public static boolean dispararBafo(ServerPlayer player, ItemStack stack) {
        if (emRecarga(player, DRAGAO_ID, COOLDOWN_DRAGAO)) return false;
        ServerLevel level = mundo(player);

        Vec3 dir = player.getViewVector(1.0f);
        Vec3 pos = player.getEyePosition().add(dir.scale(1.0));

        DragonFireball bola = EntityType.DRAGON_FIREBALL.create(level, EntitySpawnReason.TRIGGERED);
        if (bola == null) return false;
        bola.moveTo(pos.x, pos.y, pos.z, player.getYRot(), player.getXRot());
        bola.setOwner(player);
        bola.setDeltaMovement(dir.scale(1.0));
        level.addFreshEntity(bola);

        player.getCooldowns().addCooldown(stack, COOLDOWN_DRAGAO);
        marcarUso(player, DRAGAO_ID);
        return true;
    }

    // =====================================================================
    // Rajada do Warden (Escudo Lendário)
    // =====================================================================
    private static Vec3 pontoDaRajada(Vec3 olho, Vec3 olhar, double d) {
        Vec3 dir = new Vec3(olhar.x, olhar.y - DESCIDA, olhar.z).normalize();
        return olho.add(dir.scale(d));
    }

    private static void soltarRajada(ServerPlayer player) {
        ServerLevel level = mundo(player);
        Vec3 olhar = player.getViewVector(1.0f);
        Vec3 olho = player.getEyePosition();

        level.playSound(null, player.getX(), player.getY(), player.getZ(),
            SoundEvents.WARDEN_SONIC_BOOM, SoundSource.PLAYERS, 3.0f, 1.0f);

        for (int i = 1; i <= 15; i++) {
            Vec3 p = pontoDaRajada(olho, olhar, i);
            level.sendParticles(ParticleTypes.SONIC_BOOM, p.x, p.y, p.z, 1, 0.0, 0.0, 0.0, 0.0);
        }

        AABB area = new AABB(olho, pontoDaRajada(olho, olhar, ALCANCE)).inflate(4.0);
        List<Entity> alvos = level.getEntities(player, area, e -> e instanceof LivingEntity && e.isAlive());
        for (Entity e : alvos) {
            AABB caixa = e.getBoundingBox().inflate(1.5);
            boolean acertou = false;
            for (double d = 0.5; d <= ALCANCE; d += 0.5) {
                if (caixa.contains(pontoDaRajada(olho, olhar, d))) { acertou = true; break; }
            }
            if (!acertou) continue;
            LivingEntity alvo = (LivingEntity) e;

            alvo.hurtServer(level, level.damageSources().sonicBoom(player), DANO);

            Vec3 horizontal = new Vec3(olhar.x, 0, olhar.z);
            horizontal = horizontal.lengthSqr() < 1.0E-4 ? olhar : horizontal.normalize();
            alvo.setDeltaMovement(horizontal.x * KB_HORIZONTAL, KB_VERTICAL, horizontal.z * KB_HORIZONTAL);
            alvo.hurtMarked = true;
            if (alvo instanceof ServerPlayer alvoPlayer) {
                alvoPlayer.connection.send(new ClientboundSetEntityMotionPacket(alvoPlayer));
            }
        }
    }

    // =====================================================================
    // Tridente, escudo, raio e itens no chão
    // =====================================================================
    @SubscribeEvent
    public static void atacar(AttackEntityEvent e) {
        Player p = e.getEntity();
        if (p.level().isClientSide()) return;
        if (e.getTarget() instanceof LivingEntity alvo && temId(p.getMainHandItem(), TRIDENTE_ID)) {
            alvo.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 200, 2), p);
        }
    }

    @SubscribeEvent
    public static void impacto(ProjectileImpactEvent e) {
        if (!(e.getProjectile() instanceof ThrownTrident tridente)) return;
        if (tridente.level().isClientSide()) return;
        if (!(e.getRayTraceResult() instanceof EntityHitResult hit)) return;
        if (!temId(tridente.getPickupItemStackOrigin(), TRIDENTE_ID)) return;

        if (hit.getEntity() instanceof LivingEntity alvo) {
            alvo.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 200, 2), tridente.getOwner());
            if (alvo instanceof ServerPlayer jogador
                    && tridente.level().isThundering()
                    && tridente.level().canSeeSky(alvo.blockPosition())) {
                RAIO_MARCADO.put(jogador.getUUID(), ((ServerLevel) tridente.level()).getServer().getTickCount());
            }
        }
    }

    @SubscribeEvent
    public static void escudoSemDefesa(LivingShieldBlockEvent e) {
        if (temId(e.getEntity().getUseItem(), ESCUDO_ID)) {
            e.setBlocked(false);
        }
    }

    @SubscribeEvent
    public static void morte(LivingDeathEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer morto)) return;
        MinecraftServer server = morto.getServer();
        OCULTOS.remove(morto.getId());

        Integer marca = RAIO_MARCADO.remove(morto.getUUID());
        if (marca != null && server.getTickCount() - marca <= 60) {
            // tudo queima (até netherite), menos as relíquias
            for (int i = 0; i < morto.getInventory().getContainerSize(); i++) {
                ItemStack st = morto.getInventory().getItem(i);
                if (!st.isEmpty() && !isReliquia(st)) morto.getInventory().setItem(i, ItemStack.EMPTY);
            }
        }

        boolean gemeo = temId(morto.getItemBySlot(EquipmentSlot.HEAD), CAPACETE_ID) || GEMEOS.contains(morto.getUUID());
        GEMEOS.remove(morto.getUUID());
        if (gemeo) {
            for (ServerPlayer outro : server.getPlayerList().getPlayers()) {
                if (outro != morto && outro.isAlive() && GEMEOS.contains(outro.getUUID())) {
                    GEMEOS.remove(outro.getUUID());
                    ServerLevel w = mundo(outro);
                    outro.hurtServer(w, w.damageSources().genericKill(), Float.MAX_VALUE);
                }
            }
        }
    }

    // Relíquias no chão: não queimam, não somem
    @SubscribeEvent
    public static void itemNoChao(EntityJoinLevelEvent e) {
        if (e.getEntity() instanceof ItemEntity ie && isReliquia(ie.getItem())) {
            ie.setUnlimitedLifetime();
            ie.setInvulnerable(true);
        }
    }

    @SubscribeEvent
    public static void saiu(PlayerEvent.PlayerLoggedOutEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) {
            ORIGINAIS.remove(p.getUUID());
            DISFARCES.remove(p.getUUID());
            OCULTOS.remove(p.getId());
            GEMEOS.remove(p.getUUID());
        }
    }

    // =====================================================================
    // Lampião: esconder equipamento dos outros jogadores
    // =====================================================================
    public static List<Pair<EquipmentSlot, ItemStack>> filtrarEquipamento(List<Pair<EquipmentSlot, ItemStack>> original) {
        List<Pair<EquipmentSlot, ItemStack>> nova = new ArrayList<>();
        for (Pair<EquipmentSlot, ItemStack> par : original) {
            EquipmentSlot slot = par.getFirst();
            ItemStack s = par.getSecond();
            boolean manter = (slot == EquipmentSlot.CHEST && s.is(Items.ELYTRA))
                          || (slot == EquipmentSlot.HEAD && s.is(Items.CARVED_PUMPKIN));
            nova.add(manter ? par : Pair.of(slot, ItemStack.EMPTY));
        }
        return nova;
    }

    private static ClientboundSetEquipmentPacket pacoteEquipamento(ServerPlayer p) {
        List<Pair<EquipmentSlot, ItemStack>> lista = new ArrayList<>();
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            lista.add(Pair.of(slot, p.getItemBySlot(slot)));
        }
        return new ClientboundSetEquipmentPacket(p.getId(), lista);
    }

    private static List<ServerPlayer> espectadores(ServerPlayer p) {
        ServerLevel lvl = mundo(p);
        double r = Math.min(32, p.getServer().getPlayerList().getViewDistance()) * 16.0;
        List<ServerPlayer> lista = new ArrayList<>();
        for (ServerPlayer o : lvl.players()) {
            if (o != p && o.distanceToSqr(p) <= r * r) lista.add(o);
        }
        return lista;
    }

    private static void enviarEquipamento(ServerPlayer p) {
        ClientboundSetEquipmentPacket pacote = pacoteEquipamento(p);
        for (ServerPlayer v : espectadores(p)) v.connection.send(pacote);
    }

    private static void atualizarOcultacao(ServerPlayer p, boolean oculto) {
        boolean ja = OCULTOS.contains(p.getId());
        if (oculto && !ja) {
            OCULTOS.add(p.getId());
            enviarEquipamento(p);
        } else if (!oculto && ja) {
            OCULTOS.remove(p.getId());
            enviarEquipamento(p);
        }
    }

    // =====================================================================
    // Skins (Relógio Lendário)
    // =====================================================================
    private static GameProfile original(ServerPlayer p) {
        if (!DISFARCES.containsKey(p.getUUID())) {
            GameProfile vivo = p.getGameProfile(); // acompanha plugins de skin
            ORIGINAIS.put(p.getUUID(), vivo);
            return vivo;
        }
        return ORIGINAIS.computeIfAbsent(p.getUUID(), k -> p.getGameProfile());
    }

    private static List<Property> textura(GameProfile perfil) {
        return new ArrayList<>(perfil.getProperties().get("textures"));
    }

    private static void trocarSkin(ServerPlayer eu, UUID alvoUuid) {
        if (alvoUuid.equals(eu.getUUID())) {
            ((PlayerAccessor) eu).cs$setGameProfile(original(eu));
            DISFARCES.remove(eu.getUUID());
            atualizarAparencia(eu);
            return;
        }
        ServerPlayer alvo = eu.getServer().getPlayerList().getPlayer(alvoUuid);
        if (alvo == null) return;
        aplicarDisfarce(eu, alvo);
    }

    private static void aplicarDisfarce(ServerPlayer eu, ServerPlayer alvo) {
        GameProfile origEu = original(eu);
        GameProfile origAlvo = original(alvo);

        GameProfile falso = new GameProfile(origEu.getId(), origAlvo.getName());
        falso.getProperties().putAll(origAlvo.getProperties());
        ((PlayerAccessor) eu).cs$setGameProfile(falso);

        DISFARCES.put(eu.getUUID(), new Disfarce(alvo.getUUID(), textura(origAlvo)));
        atualizarAparencia(eu);
    }

    private static void acompanharSkins(MinecraftServer server) {
        for (UUID uuid : new ArrayList<>(DISFARCES.keySet())) {
            Disfarce d = DISFARCES.get(uuid);
            ServerPlayer eu = server.getPlayerList().getPlayer(uuid);
            ServerPlayer alvo = server.getPlayerList().getPlayer(d.alvo);
            if (eu == null || alvo == null) continue;
            if (!textura(original(alvo)).equals(d.textura)) {
                aplicarDisfarce(eu, alvo);
            }
        }
    }

    private static void atualizarAparencia(ServerPlayer p) {
        MinecraftServer server = p.getServer();
        Set<ServerPlayer> vendo = new HashSet<>(espectadores(p));

        ClientboundPlayerInfoRemovePacket remover = new ClientboundPlayerInfoRemovePacket(List.of(p.getUUID()));
        ClientboundPlayerInfoUpdatePacket adicionar = new ClientboundPlayerInfoUpdatePacket(
            EnumSet.of(ClientboundPlayerInfoUpdatePacket.Action.ADD_PLAYER,
                       ClientboundPlayerInfoUpdatePacket.Action.INITIALIZE_CHAT,
                       ClientboundPlayerInfoUpdatePacket.Action.UPDATE_GAME_MODE,
                       ClientboundPlayerInfoUpdatePacket.Action.UPDATE_LISTED,
                       ClientboundPlayerInfoUpdatePacket.Action.UPDATE_LATENCY,
                       ClientboundPlayerInfoUpdatePacket.Action.UPDATE_DISPLAY_NAME),
            List.of(p));

        ServerEntity entrada = new ServerEntity(mundo(p), p, 1, false, pacote -> { });

        for (ServerPlayer v : server.getPlayerList().getPlayers()) {
            boolean ve = vendo.contains(v);
            if (ve) v.connection.send(new ClientboundRemoveEntitiesPacket(p.getId()));
            v.connection.send(remover);
            v.connection.send(adicionar);
            if (ve) {
                entrada.sendPairingData(v, v.connection::send);
            }
        }
    }

    // =====================================================================
    // Bússola Lendária
    // =====================================================================
    private static void escolherAlvo(ServerPlayer eu, UUID alvoUuid, InteractionHand hand) {
        ServerPlayer alvo = eu.getServer().getPlayerList().getPlayer(alvoUuid);
        if (alvo == null) return;

        ItemStack bussola = eu.getItemInHand(hand);
        if (!temId(bussola, BUSSOLA_ID)) {
            bussola = ItemStack.EMPTY;
            for (int i = 0; i < eu.getInventory().getContainerSize(); i++) {
                ItemStack s = eu.getInventory().getItem(i);
                if (temId(s, BUSSOLA_ID)) { bussola = s; break; }
            }
        }
        if (bussola.isEmpty()) return;

        CustomData.update(DataComponents.CUSTOM_DATA, bussola, nbt -> nbt.putString("CsAlvo", alvoUuid.toString()));
        atualizarBussola(bussola, eu.getServer());

        eu.sendSystemMessage(Component.literal("\u00a7aVoc\u00ea Selecionou o Jogador \u00a7f"
            + original(alvo).getName() + " \u00a7acomo alvo"));
    }

    private static void atualizarBussola(ItemStack s, MinecraftServer server) {
        CustomData dados = s.get(DataComponents.CUSTOM_DATA);
        String a = dados == null ? "" : dados.copyTag().getString("CsAlvo");
        ServerPlayer alvo = null;
        if (!a.isEmpty()) {
            try {
                alvo = server.getPlayerList().getPlayer(UUID.fromString(a));
            } catch (IllegalArgumentException ignored) { }
        }

        if (alvo == null) {
            if (s.has(DataComponents.LODESTONE_TRACKER)) {
                s.remove(DataComponents.LODESTONE_TRACKER);
            }
            return;
        }

        BlockPos pos = alvo.blockPosition();
        GlobalPos nova = GlobalPos.of(alvo.level().dimension(), pos);
        LodestoneTracker atual = s.get(DataComponents.LODESTONE_TRACKER);
        boolean atualizar = atual == null || atual.target().isEmpty()
            || !atual.target().get().dimension().equals(nova.dimension())
            || atual.target().get().pos().distSqr(pos) >= 4;
        if (atualizar) {
            s.set(DataComponents.LODESTONE_TRACKER, new LodestoneTracker(Optional.of(nova), false));
        }
    }

    // =====================================================================
    // Menus
    // =====================================================================
    private static void abrirSelecao(ServerPlayer player, boolean excluirEu, BiConsumer<ServerPlayer, UUID> acao) {
        List<ServerPlayer> jogadores = new ArrayList<>(player.getServer().getPlayerList().getPlayers());
        if (excluirEu) jogadores.remove(player);

        int linhas = Math.max(1, Math.min(6, (jogadores.size() + 8) / 9));
        SimpleContainer inv = new SimpleContainer(linhas * 9) {
            @Override
            public boolean canPlaceItem(int slot, ItemStack stack) {
                return false;
            }
        };
        List<UUID> ids = new ArrayList<>();
        for (int i = 0; i < jogadores.size() && i < linhas * 9; i++) {
            ServerPlayer j = jogadores.get(i);
            inv.setItem(i, cabeca(original(j)));
            ids.add(j.getUUID());
        }

        player.openMenu(new SimpleMenuProvider(
            (syncId, pinv, p) -> new MenuSelecao(syncId, pinv, inv, linhas, ids, acao),
            Component.literal("Selecione um jogador")));
    }

    private static ItemStack cabeca(GameProfile perfil) {
        ItemStack s = new ItemStack(Items.PLAYER_HEAD);
        s.set(DataComponents.PROFILE, new ResolvableProfile(perfil));
        s.set(DataComponents.CUSTOM_NAME, Component.literal(perfil.getName())
            .withStyle(Style.EMPTY.withColor(ChatFormatting.WHITE).withItalic(false)));
        return s;
    }

    private static void abrirMenu(ServerPlayer player) {
        lookup = player.getServer().registryAccess();

        SimpleContainer menu = new SimpleContainer(18) {
            @Override
            public boolean canPlaceItem(int slot, ItemStack stack) {
                return false;
            }
        };
        menu.setItem(0, criarEspada());
        menu.setItem(1, comBrilho(base(Items.FEATHER, "Pena Lend\u00e1ria", PENA_ID)));
        menu.setItem(2, comRecarga(comBrilho(base(Items.SHIELD, "Escudo Lend\u00e1rio", ESCUDO_ID)), 10.0f, "escudo"));
        menu.setItem(3, criarPocao());
        menu.setItem(4, criarTridente());
        menu.setItem(5, criarPicareta());
        menu.setItem(6, criarCapacete());
        menu.setItem(7, criarDragao());
        menu.setItem(8, comBrilho(base(Items.CLOCK, "Rel\u00f3gio Lend\u00e1rio", RELOGIO_ID)));
        menu.setItem(9, comBrilho(base(Items.SOUL_LANTERN, "Lampi\u00e3o Lend\u00e1rio", LAMPIAO_ID)));
        menu.setItem(10, comBrilho(base(Items.COMPASS, "B\u00fassola Lend\u00e1ria", BUSSOLA_ID)));
        menu.setItem(11, criarBatata());
        menu.setItem(12, criarBota());

        Component titulo = Component.literal("CS").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD)
            .append(Component.literal("\u00bb ").setStyle(Style.EMPTY.withColor(ChatFormatting.GRAY).withBold(false)))
            .append(Component.literal("Rel\u00edquia").setStyle(Style.EMPTY.withColor(ChatFormatting.GRAY).withBold(false)));

        player.openMenu(new SimpleMenuProvider(
            (syncId, inv, p) -> new MenuReliquia(syncId, inv, menu, 2), titulo));
    }

    // =====================================================================
    // Criação dos itens
    // =====================================================================
    private static ItemStack base(Item material, String nome, String id) {
        ItemStack stack = new ItemStack(material);
        stack.set(DataComponents.CUSTOM_NAME, Component.literal(nome)
            .withStyle(Style.EMPTY.withColor(ChatFormatting.YELLOW)
                .withBold(true).withUnderlined(true).withItalic(true)));
        stack.set(DataComponents.UNBREAKABLE, new Unbreakable(false));
        CompoundTag nbt = new CompoundTag();
        nbt.putString(TAG, id);
        stack.set(DataComponents.CUSTOM_DATA, CustomData.of(nbt));
        return stack;
    }

    private static ItemStack comRecarga(ItemStack s, float segundos, String grupo) {
        s.set(DataComponents.USE_COOLDOWN,
            new UseCooldown(segundos, Optional.of(ResourceLocation.fromNamespaceAndPath("csreliquia", grupo))));
        return s;
    }

    private static ItemStack comBrilho(ItemStack s) {
        s.set(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, true);
        return s;
    }

    private static void encantar(ItemStack s, ResourceKey<Enchantment> chave, int nivel) {
        Holder<Enchantment> e = lookup.lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(chave);
        s.enchant(e, nivel);
    }

    private static ItemStack esconderEncantos(ItemStack s) {
        ItemEnchantments c = s.get(DataComponents.ENCHANTMENTS);
        if (c != null) s.set(DataComponents.ENCHANTMENTS, c.withTooltip(false));
        return s;
    }

    private static ItemStack criarEspada() {
        ItemStack s = base(Items.GOLDEN_SWORD, "Espada do Ca\u00e7ador", ESPADA_ID);
        encantar(s, Enchantments.KNOCKBACK, 10);
        return esconderEncantos(s);
    }

    private static ItemStack criarPocao() {
        ItemStack s = base(Items.SPLASH_POTION, "Po\u00e7\u00e3o Lend\u00e1ria", POCAO_ID);
        s.set(DataComponents.POTION_CONTENTS, new PotionContents(
            Optional.empty(), Optional.of(16711935),
            List.of(new MobEffectInstance(MobEffects.BLINDNESS, 4, 0)), Optional.empty()));
        s.set(DataComponents.HIDE_ADDITIONAL_TOOLTIP, Unit.INSTANCE);
        encantar(s, Enchantments.UNBREAKING, 1);
        comRecarga(s, 5.0f, "pocao");
        return esconderEncantos(s);
    }

    private static ItemStack criarTridente() {
        ItemStack s = base(Items.TRIDENT, "Tridente Lend\u00e1rio", TRIDENTE_ID);
        encantar(s, Enchantments.IMPALING, 5);
        encantar(s, Enchantments.LOYALTY, 3);
        encantar(s, Enchantments.CHANNELING, 1);
        encantar(s, Enchantments.UNBREAKING, 3);
        encantar(s, Enchantments.MENDING, 1);
        return esconderEncantos(s);
    }

    private static ItemStack criarPicareta() {
        ItemStack s = base(Items.IRON_PICKAXE, "Picareta Lend\u00e1ria", PICARETA_ID);
        encantar(s, Enchantments.EFFICIENCY, 13);
        return esconderEncantos(s);
    }

    private static ItemStack criarDragao() {
        ItemStack s = base(Items.DRAGON_HEAD, "Drag\u00e3o Lend\u00e1rio", DRAGAO_ID);
        comRecarga(s, 10.0f, "dragao");
        encantar(s, Enchantments.UNBREAKING, 1);
        return esconderEncantos(s);
    }

    private static ItemStack criarBatata() {
        ItemStack s = base(Items.POISONOUS_POTATO, "Batata do Bobo", BATATA_ID);
        encantar(s, Enchantments.UNBREAKING, 1);
        return esconderEncantos(s);
    }

    private static ItemStack criarBota() {
        ItemStack s = base(Items.DIAMOND_BOOTS, "Bota Lend\u00e1ria", BOTA_ID);
        encantar(s, Enchantments.PROTECTION, 4);
        encantar(s, Enchantments.FEATHER_FALLING, 4);
        encantar(s, Enchantments.DEPTH_STRIDER, 3);
        encantar(s, Enchantments.SOUL_SPEED, 3);
        encantar(s, Enchantments.THORNS, 3);
        encantar(s, Enchantments.UNBREAKING, 3);
        encantar(s, Enchantments.MENDING, 1);
        return esconderEncantos(s);
    }

    private static ItemStack criarCapacete() {
        ItemStack s = base(Items.TURTLE_HELMET, "Capacete Lend\u00e1rio dos G\u00eameos", CAPACETE_ID);
        s.set(DataComponents.ATTRIBUTE_MODIFIERS, ItemAttributeModifiers.builder()
            .add(Attributes.MAX_HEALTH,
                new AttributeModifier(ResourceLocation.fromNamespaceAndPath("csreliquia", "gemeos_vida"), 10.0,
                    AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.HEAD)
            .add(Attributes.ARMOR,
                new AttributeModifier(ResourceLocation.fromNamespaceAndPath("csreliquia", "gemeos_armadura"), 2.0,
                    AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.HEAD)
            .build().withTooltip(false));
        encantar(s, Enchantments.UNBREAKING, 1);
        return esconderEncantos(s);
    }
}
