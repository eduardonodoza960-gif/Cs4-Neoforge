package com.cs.reliquia.mixin.client;

import com.cs.reliquia.client.CsReliquiaClient;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.player.AbstractClientPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(AbstractClientPlayer.class)
public abstract class AbstractClientPlayerSkinMixin {

    // Na SUA tela o seu personagem usa a skin escolhida com /csskin
    @SuppressWarnings({"rawtypes", "unchecked"})
    @Inject(method = "getSkin", at = @At("HEAD"), cancellable = true)
    private void cs$skinEscolhida(CallbackInfoReturnable cir) {
        if (CsReliquiaClient.SKIN_ALVO == null) return;
        AbstractClientPlayer self = (AbstractClientPlayer) (Object) this;
        Minecraft mc = Minecraft.getInstance();
        if (self != mc.player || mc.getConnection() == null) return;
        PlayerInfo alvo = mc.getConnection().getPlayerInfo(CsReliquiaClient.SKIN_ALVO);
        if (alvo != null) {
            cir.setReturnValue(alvo.getSkin());
        }
    }
}
