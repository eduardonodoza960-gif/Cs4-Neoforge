package com.cs.reliquia;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.MenuType;

import java.util.List;
import java.util.UUID;
import java.util.function.BiConsumer;

/** Menu "Selecione um jogador": clicar escolhe o jogador; nada pode ser movido (nem no seu inventário). */
public class MenuSelecao extends ChestMenu {

    private final int tamanho;
    private final List<UUID> alvos;
    private final BiConsumer<ServerPlayer, UUID> acao;

    public MenuSelecao(int syncId, Inventory inv, Container menu, int linhas,
                       List<UUID> alvos, BiConsumer<ServerPlayer, UUID> acao) {
        super(tipo(linhas), syncId, inv, menu, linhas);
        this.tamanho = linhas * 9;
        this.alvos = alvos;
        this.acao = acao;
    }

    private static MenuType<ChestMenu> tipo(int linhas) {
        return switch (linhas) {
            case 1 -> MenuType.GENERIC_9x1;
            case 2 -> MenuType.GENERIC_9x2;
            case 3 -> MenuType.GENERIC_9x3;
            case 4 -> MenuType.GENERIC_9x4;
            case 5 -> MenuType.GENERIC_9x5;
            default -> MenuType.GENERIC_9x6;
        };
    }

    @Override
    public void clicked(int slotId, int button, ClickType clickType, Player player) {
        if (slotId >= 0 && slotId < tamanho
                && (clickType == ClickType.PICKUP || clickType == ClickType.QUICK_MOVE)
                && slotId < alvos.size() && player instanceof ServerPlayer sp) {
            UUID alvo = alvos.get(slotId);
            this.broadcastFullState();
            sp.closeContainer();
            acao.accept(sp, alvo);
            return;
        }
        this.broadcastFullState();
    }
}
