package com.cs.reliquia.mixin.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.protocol.game.ClientboundPlayerInfoRemovePacket;
import net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Limpa o cache da skin do jogador local quando a lista de jogadores muda (para a troca de skin aparecer na sua tela). */
@Mixin(ClientPacketListener.class)
public abstract class ClientPacketListenerMixin {

    @Inject(method = "handlePlayerInfoUpdate", at = @At("TAIL"))
    private void cs$atualizada(ClientboundPlayerInfoUpdatePacket packet, CallbackInfo ci) {
        cs$limpar();
    }

    @Inject(method = "handlePlayerInfoRemove", at = @At("TAIL"))
    private void cs$removida(ClientboundPlayerInfoRemovePacket packet, CallbackInfo ci) {
        cs$limpar();
    }

    @Unique
    private static void cs$limpar() {
        try {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null) {
                ((AbstractClientPlayerAccessor) mc.player).cs$setPlayerInfo(null);
            }
        } catch (Throwable ignored) {
        }
    }
}
