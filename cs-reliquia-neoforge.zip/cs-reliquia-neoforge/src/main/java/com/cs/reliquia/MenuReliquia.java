package com.cs.reliquia;

import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.ItemStack;

/** Menu onde o item nunca acaba: clicar dá uma cópia e o menu continua igual. */
public class MenuReliquia extends ChestMenu {

    private final int tamanhoMenu;

    public MenuReliquia(int syncId, Inventory inv, Container menu, int linhas) {
        super(linhas == 2 ? MenuType.GENERIC_9x2 : MenuType.GENERIC_9x3, syncId, inv, menu, linhas);
        this.tamanhoMenu = linhas * 9;
    }

    @Override
    public void clicked(int slotId, int button, ClickType clickType, Player player) {
        if (slotId >= 0 && slotId < tamanhoMenu) {
            if (clickType == ClickType.PICKUP || clickType == ClickType.QUICK_MOVE
                    || clickType == ClickType.SWAP || clickType == ClickType.THROW) {
                ItemStack item = this.slots.get(slotId).getItem();
                if (!item.isEmpty()) {
                    player.getInventory().placeItemBackInInventory(item.copy());
                }
            }
            this.broadcastFullState();
            return;
        }
        if (clickType == ClickType.PICKUP_ALL) {
            this.broadcastFullState();
            return;
        }
        super.clicked(slotId, button, clickType, player);
    }
}
