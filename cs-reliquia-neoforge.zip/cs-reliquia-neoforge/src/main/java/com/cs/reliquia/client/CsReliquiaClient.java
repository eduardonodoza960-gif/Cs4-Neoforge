package com.cs.reliquia.client;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.commands.Commands;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterClientCommandsEvent;

import java.util.UUID;

/**
 * Parte do mod que roda só no seu Minecraft (funciona em qualquer servidor).
 * /csskin <jogador>  -> você passa a ver a skin desse jogador no seu personagem (só na sua tela)
 * /csskin reset      -> volta a sua skin
 */
@EventBusSubscriber(modid = "csreliquia", value = Dist.CLIENT)
public class CsReliquiaClient {

    public static volatile UUID SKIN_ALVO = null;

    @SubscribeEvent
    public static void comandos(RegisterClientCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("csskin")
            .then(Commands.literal("reset").executes(ctx -> {
                SKIN_ALVO = null;
                return 1;
            }))
            .then(Commands.argument("jogador", StringArgumentType.word())
                .suggests((ctx, builder) -> {
                    Minecraft mc = Minecraft.getInstance();
                    if (mc.getConnection() != null) {
                        for (PlayerInfo e : mc.getConnection().getOnlinePlayers()) {
                            builder.suggest(e.getProfile().getName());
                        }
                    }
                    return builder.buildFuture();
                })
                .executes(ctx -> {
                    String nome = StringArgumentType.getString(ctx, "jogador");
                    Minecraft mc = Minecraft.getInstance();
                    if (mc.getConnection() != null) {
                        for (PlayerInfo e : mc.getConnection().getOnlinePlayers()) {
                            if (e.getProfile().getName().equalsIgnoreCase(nome)) {
                                SKIN_ALVO = e.getProfile().getId();
                                break;
                            }
                        }
                    }
                    return 1;
                })));
    }
}
